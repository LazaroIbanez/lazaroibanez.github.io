# Lazaro Ibanez Landing Page

### lazaroibanez.github.io

Start Bootstrap Creative is released under the MIT Licence (https://en.wikipedia.org/wiki/MIT_License).

Inspired by Start Bootstrap Creative Design (https://startbootstrap.com/template-overviews/creative/)

Modified and Redesigned by Lazaro Ibanez (https://lazaroibanez.github.io/)

### Change Logs:
* 13/08/2017 Landing Page created
* 25/08/2017 Background change
* 04/10/2017 Google Analytics Tracking Code added
* 20/10/2017 Background change
* 11/11/2017 favicon.ico added
* 24/02/2018 Profile updated
* 14/07/2018 Position name updated


© Lazaro Ibanez 2018 All Rights reserved.
